package com.example.navigation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class PermissionRequest extends AppCompatActivity implements View.OnClickListener {
    private static final int ERROR_DIALOG_REQUEST = 3; //
    private static final int LOCATION_REQUEST = 1;
    //declare vars for request permission and check for google play services
    private Button btn;
    private FusedLocationProviderClient fusedLocationProviderClient;
    //declare vars for button and FusedLocationProviderClient
    public double locationTextLAT;
    public double locationTextLong;
    //declare vars for latitude and longitude
    public boolean GooglePlay;
    public boolean MapsEnabled;
    //declare vars for checking if maps is enabled and google play services is enabled

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_request);
        //creates constructor and sets layout
        getSupportActionBar().setTitle("Permission Request");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //sets title opf action bar and enables back button
        btn = (Button) findViewById(R.id.RequestPermissionbutton);
        btn.setOnClickListener(this);
        //finds the button and sets an on click listener

    }


    @Override
    public void onClick(View view) {
        //checks if GPS is enabled
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Unable to contact location services, please check your settings and try again.", Toast.LENGTH_LONG).show();
            MapsEnabled = false;
        }else{
            MapsEnabled = true;

        }

        //checks if google play services is enabled
        int Gavailable = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(PermissionRequest.this);

        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST );

        }
        if ((Gavailable == ConnectionResult.SUCCESS)) {
            Toast.makeText(this, "Google Services", Toast.LENGTH_LONG).show();
            GooglePlay = true;

        } else if (GoogleApiAvailability.getInstance().isUserResolvableError(Gavailable)) {
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(PermissionRequest.this, Gavailable, ERROR_DIALOG_REQUEST);
            dialog.show();
            GooglePlay = false;
        }else if(!(Gavailable == ConnectionResult.SUCCESS)){
            Toast.makeText(this, "Unable to contact Google Services. Check your location services and try again", Toast.LENGTH_LONG).show();
            GooglePlay = false;


        }

        //starts the maps activity if all requirements are met
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if(location != null && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && GooglePlay == true && MapsEnabled == true){


                            locationTextLAT = location.getLatitude();
                            locationTextLong = location.getLongitude();

                            Intent intent = new Intent(PermissionRequest.this, MapsActivity.class);
                            intent.putExtra("LAT", locationTextLAT);
                            intent.putExtra("Long", locationTextLong);
                            startActivity(intent);

                        }
                    }
                });
    }
}