package com.example.navigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener {

    private TextView banner, registerUser;
    private EditText editTextFullName, editTextAge, editTextEmail, editTextpassword;
    private ProgressBar progressBar;
    //declare all components
    private FirebaseAuth mAuth;
    /// declare a firebase authentication
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
        //creates constructor and sets layout
        mAuth = FirebaseAuth.getInstance();
        //gets an instance of firebase
        getSupportActionBar().setTitle("Register");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //sets title on action bar and enables back button
        banner = (TextView) findViewById(R.id.banner);
        banner.setOnClickListener(this);
        registerUser = (Button) findViewById(R.id.Login_Button);
        registerUser.setOnClickListener(this);
        //enables on click listeners for both the main banner  and register user button
        editTextFullName = (EditText) findViewById(R.id.editTextPasswordSignIn);
        editTextAge = (EditText) findViewById(R.id.editTextAge);
        editTextEmail = (EditText) findViewById(R.id.editTextEmailAddressSignIn);
        editTextpassword = (EditText) findViewById(R.id.editTextPassword);
        progressBar = (ProgressBar) findViewById(R.id.ProgressBar1);
        //finds and stores all the components onn the layout file in vars
    }

    @Override
    public void onClick(View v) {//uses switch statement to start specific functions depending what is clicked
        switch(v.getId()){
            case R.id.banner:
                startActivity(new Intent(this, Login.class));
                break;
            case R.id.Login_Button:
                RegisterUser();// starts register user function
                break;
        }

    }


    private void RegisterUser(){
        String email = editTextEmail.getText().toString().trim();
        String password = editTextpassword.getText().toString().trim();
        String fullName = editTextFullName.getText().toString().trim();
        String age = editTextAge.getText().toString().trim();
        //gets input from each field, coverts them to string and trims.

        //input validation for each field
        if(fullName.isEmpty()){
            editTextFullName.setError("Full name Is Required");
            editTextFullName.requestFocus();
            return;
        }

        if(email.isEmpty()){
            editTextEmail.setError("Email Is Required");
            editTextEmail.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail.setError("Please Provide Valid Email");
            editTextEmail.requestFocus();
            return;
        }


        if(age.isEmpty()){
            editTextAge.setError("Age Is Required");
            editTextAge.requestFocus();
            return;


        }


        if(password.isEmpty()){
            editTextpassword.setError("Password Is Required");
            editTextpassword.requestFocus();
            return;
        }

        if(password.length() < 6){
            editTextpassword.setError("Min Password length Should Be 6 Characters");
            editTextpassword.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        //creates user on firebase
        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                       if (task.isSuccessful())
                       {

                           User user = new User(fullName, age, email);
                           FirebaseDatabase.getInstance().getReference("Users")
                                   .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                   .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                               @Override
                               public void onComplete(@NonNull Task<Void> task) {
                                   if(task.isSuccessful()){

                                       Toast.makeText(RegisterUser.this, "User has been registered", Toast.LENGTH_LONG).show();
                                       progressBar.setVisibility(View.GONE);
                                   }else{

                                      Toast.makeText(RegisterUser.this, "Failed to register! Try again", Toast.LENGTH_LONG).show();
                                       progressBar.setVisibility(View.GONE);
                                   }
                               }
                           });
                       }else{
                           Toast.makeText(RegisterUser.this, "Failed to register! Try again", Toast.LENGTH_LONG).show();
                           progressBar.setVisibility(View.GONE);

                       }
                    }
                });

    }


}