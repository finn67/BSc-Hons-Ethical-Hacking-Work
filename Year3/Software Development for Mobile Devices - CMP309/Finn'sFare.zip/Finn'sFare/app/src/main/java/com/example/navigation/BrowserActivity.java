package com.example.navigation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class BrowserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        //creates constructor and set layout

        String URL = getIntent().getExtras().getString("URL");
        String URL1 = getIntent().getExtras().getString("URL1");
        String URL2 = getIntent().getExtras().getString("URL2");
        String URL3 = getIntent().getExtras().getString("URL3");
        String URL4 = getIntent().getExtras().getString("URL4");
        String URL5 = getIntent().getExtras().getString("URL5");
        //gets intent data(URL) from the maps activity

        WebView webView = findViewById(R.id.webView); // stores the webview in a var
        webView.setWebChromeClient(new WebChromeClient()); // sets browser to use chrome
        webView.loadUrl(URL);
        webView.loadUrl(URL1);
        webView.loadUrl(URL2);
        webView.loadUrl(URL3);
        webView.loadUrl(URL4);
        webView.loadUrl(URL5);
        // loads whichever url is passed into the web view
    }
}