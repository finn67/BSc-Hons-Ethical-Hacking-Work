package com.example.navigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserAccount extends AppCompatActivity {

    private Button logout;
    public FirebaseUser user;
    public DatabaseReference reference;
    public String userID;
    private Button Home;
    //declaring all vars


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_account);
        //creating the constructor and setting the layout
        getSupportActionBar().setTitle("User Account");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //enabling back button on action bar and setting title

        logout = (Button)findViewById(R.id.LogoutButton);
        Home = (Button)findViewById(R.id.Home);
        //storing buttons in vars


        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(UserAccount.this, MainActivity.class));// starts home activity when home button is clicked
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut(); // uses firebases function to logout when button is clicked
                startActivity(new Intent(UserAccount.this, MainActivity.class));// starts main activity after log out
            }
        });

        user = FirebaseAuth.getInstance().getCurrentUser();// storing the user in a var
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userID = user.getUid(); // getting user id and storing it



        final TextView greetingTextView = (TextView)findViewById(R.id.WelcomeUser);
        final TextView fullNametextView = (TextView)findViewById(R.id.FullNameUser);
        final TextView emailTextView = (TextView)findViewById(R.id.EmailAddressUser);
        final TextView ageTextVeiw = (TextView)findViewById(R.id.AgeUser);
        // storing specific text views in vars


        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() { //
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userProfile = snapshot.getValue(User.class); // gets the user class
                if(userProfile != null){
                    String fullName = userProfile.fullName; // store name in a var
                    String email = userProfile.email; // store email in a var
                    String age = userProfile.age; // store age in a var
                    greetingTextView.setText("Welcome, " + fullName + "!"); // displays a welcome message with the of user
                    fullNametextView.setText(fullName); // displays the name of user
                    emailTextView.setText(email); // displays the email of user
                    ageTextVeiw.setText(age); //  displays age of user


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserAccount.this, "Something wrong happned", Toast.LENGTH_LONG).show();
            }
        });



    }
}