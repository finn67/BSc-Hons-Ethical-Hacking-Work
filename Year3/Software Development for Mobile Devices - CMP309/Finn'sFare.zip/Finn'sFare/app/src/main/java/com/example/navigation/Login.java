package com.example.navigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity implements View.OnClickListener {

    private TextView register, forgotPassword; // declaring text views for forgot password and register
    private EditText editTextEmail, editTextPassword; // declaring input boxes for email an dpassword
    private Button signIn; // declaring sign in button

    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    //declaring firebase vars, one for auth and progress bar


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //creates constructor
        setContentView(R.layout.activity_login2); // sets layout to activity_login2.xml

        register = (TextView) findViewById(R.id.UserReg);
        register.setOnClickListener(this);
        //sets register as user reg and creates a click listener on the User reg text view.
        signIn = (Button) findViewById(R.id.Login_Button);
        signIn.setOnClickListener(this);
        //sets sign in as Login Button and creates a click listener on the Login button.
        getSupportActionBar().setTitle("Log In");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //sets title of action bar to login and enables back button

        editTextEmail = (EditText)findViewById(R.id.editTextEmailAddressSignIn);
        editTextPassword = (EditText)findViewById(R.id.editTextPasswordSignIn);
        progressBar = (ProgressBar)findViewById(R.id.ProgressBar1);
        //assigns each object to their vars by using id
        mAuth = FirebaseAuth.getInstance();
        //creates an instance of firebase auth and assigns it to mauth
        forgotPassword = (TextView)findViewById(R.id.ForgotPassword);
        forgotPassword.setOnClickListener(this);
        // assigns var to the text view and sets an onclick listener
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.UserReg:
                startActivity(new Intent(this, RegisterUser.class));//starts register activty if the register text view is clicked on
                break;

            case R.id.Login_Button:
                userLogin(); // runs the userLogin function if login button is clicked
                break;

            case R.id.ForgotPassword:
                startActivity(new Intent(this, ForgotPassword.class)); // starts forgot password activity if text view forgot password is cliked
                break;
        }





    }

    private void userLogin(){
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        // gets input from individual fields and stores them in vars

        if(email.isEmpty()){ //input validation for if the email field is empty
            editTextEmail.setError("Email is required");
            editTextEmail.requestFocus();
            return;


        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){ // input validation making sure the email address follows a proper pattern
            editTextEmail.setError("please enter a valid email");
            editTextEmail.requestFocus();
            return;



        }

        if(password.isEmpty()){ //input validation for if the passwords field is empty
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;

        }

        if(password.length() < 6){ // input validaation making sure the password is greater than a 6 length
            editTextPassword.setError("Min password length is 6 characters");
            editTextPassword.requestFocus();
            return;


        }

        progressBar.setVisibility(View.VISIBLE); // displays progress bar
        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() { // uses the fire base instance to log in with the email and password
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); // gets the current user if the log in is correct

                    if(user.isEmailVerified()){ // checks if email is verified
                        progressBar.setVisibility(View.INVISIBLE); // stops progress bar
                        startActivity(new Intent(Login.this, UserAccount.class)); // opens user account page


                    }else{ // if email is not verified a verification email is sent using a firebase function
                        progressBar.setVisibility(View.INVISIBLE); // stops progress bar
                        user.sendEmailVerification();
                        Toast.makeText(Login.this, "Check your email to verify your account", Toast.LENGTH_LONG).show();
                    }



                }else{

                    Toast.makeText(Login.this, "Failed to log in", Toast.LENGTH_LONG).show();
                    
                }
            }
        });

    }



}