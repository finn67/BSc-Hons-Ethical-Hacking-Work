package com.example.navigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPassword extends AppCompatActivity {

    private EditText emailEditText;
    private Button resetPasswordButton;
    private ProgressBar progressBar;
    //declares all vars
    FirebaseAuth auth;
    //declares firebase auth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        //creates constructor and set layout
        emailEditText = (EditText)findViewById(R.id.editTextEmailAddressForgotPassword);
        resetPasswordButton = (Button)findViewById(R.id.Reset_Button);
        progressBar = (ProgressBar)findViewById(R.id.progressBarForgotPassword);
        //assigns components to vars

        getSupportActionBar().setTitle("Forgot Password");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //sets the title of action bar and enables the back button on the action bar
        auth = FirebaseAuth.getInstance();

        resetPasswordButton.setOnClickListener(new View.OnClickListener() {// initializes a on click the reset password button
            @Override
            public void onClick(View view) {
                resetPassword(); //calls reset password function
            }
        });

    }


    private void resetPassword(){

        String email = emailEditText.getText().toString().trim(); // gets input from email text box

        if(email.isEmpty()){// input validation of email seeing if its empty
            emailEditText.setError("Email is required");// displays error indicator on email input box
            emailEditText.requestFocus();
            return;

        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){// input validation of email seeing if matches email patterns
            emailEditText.setError("please provide a valid email");// displays error indicator on email input box
            emailEditText.requestFocus();
            return;


        }

        progressBar.setVisibility(View.VISIBLE);// displays progress bar
        auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {// sends email reset password
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if ((task.isSuccessful())){
                    Toast.makeText(ForgotPassword.this, "check your email to reset your password", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.INVISIBLE);
                    
                }else{

                    Toast.makeText(ForgotPassword.this, "Try again!", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

}