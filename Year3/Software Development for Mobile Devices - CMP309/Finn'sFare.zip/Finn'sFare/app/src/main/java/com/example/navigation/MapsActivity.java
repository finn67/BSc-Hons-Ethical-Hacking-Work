package com.example.navigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener, Recycler.UserListRecyclerClickListner {
    RecyclerView recyclerView;
    Recycler adapter;
    // declares both the adapter and recycler view
    FloatingActionButton fab, fab1, fab2, fab3;
    // declares all the FABS
    Animation fabOpen, fabClose, rotateForward, rotateBackward;
    // declares all the animation vars
    boolean isOpen = false;

    int[] images = {R.drawable.grill21, R.drawable.brewhouse, R.drawable.theoldboatyard, R.drawable.porticullis, R.drawable.mcds, R.drawable.kfc}; // find all images for each establishment and store them in array
    String Food[]={"Grill21", "Brewhouse", "Boatyard", "Porticullis", "MCDS", "KFC"}; // store titles in a arrayu
    String URL[] = {"https://www.thegrill21.co.uk/Home","https://www.oldbrewhousearbroath.co.uk/", "https://www.oldboatyard.co.uk/", "https://www.facebook.com/portcullis17/", "https://www.mcdonalds.com/gb/en-gb.html", "https://www.kfc.co.uk/" }; //storing URLs in array

    public LatLng Grill21Pos;
    public LatLng  BrewhousePos;
    public LatLng  BoatyardPos;
    public LatLng  PortcullisPos;
    public LatLng  McdsPos;
    public LatLng  KFCPos;
    //declaring all latlngs
    private GoogleMap map;
    private Marker Grill21;
    private Marker BrewHouse;
    private Marker Boatyard;
    private Marker Portcullis;
    private Marker Mcds;
    private Marker KFC;
    private Marker Current;
    //declaring all markers
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        //creating constructor and setting layout to activity maps
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        getSupportActionBar().setTitle("Map");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //sets title of action bar to login and enables back button
        recyclerView = findViewById(R.id.recyclerView); // store recycler view in var
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // set its layout to this
        adapter = new Recycler(this,Food, this::onUserClicked,images); //
        recyclerView.setAdapter(adapter);
        // sets adapter
    }

    @Override
    protected void onStart() {
        super.onStart();



    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */




    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.map = googleMap;

        double LAT = getIntent().getExtras().getDouble("LAT");
        double LONG = getIntent().getExtras().getDouble("Long");
        // gets location from the permission activity
        fab = (FloatingActionButton)findViewById(R.id.floatingActionButtonKey);
        fab1 = (FloatingActionButton)findViewById(R.id.floatingActionButtonBlueMarker);
        fab2 = (FloatingActionButton)findViewById(R.id.floatingActionButtonRedMarker);
        fab3 = (FloatingActionButton)findViewById(R.id.floatingActionButtonYellowMarker);
        //stores all fabs in vars
        fabOpen = AnimationUtils.loadAnimation(this, R.anim.fab_open);
        fabClose = AnimationUtils.loadAnimation(this, R.anim.fab_closed);
        rotateForward = AnimationUtils.loadAnimation(this,R.anim.rotate_forward);
        rotateBackward = AnimationUtils.loadAnimation(this,R.anim.rotate_backward);
        //sets the animation files to vars

fab.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        animateFab(); // calls animation function when first fab is clicked

    }
});

fab1.setOnClickListener(new View.OnClickListener() { // displays toast when fab is clicked
    @Override
    public void onClick(View view) {
        Toast.makeText(MapsActivity.this, "The Blue markers display restaurants located in Arbroath ", Toast.LENGTH_SHORT).show();
    }
});

fab2.setOnClickListener(new View.OnClickListener() {// displays toast when fab is clicked
    @Override
    public void onClick(View view) {
        Toast.makeText(MapsActivity.this, "The Red marker displays your current location ", Toast.LENGTH_SHORT).show();
    }
});

fab3.setOnClickListener(new View.OnClickListener() {// displays toast when fab is clicked
    @Override
    public void onClick(View view) {
        Toast.makeText(MapsActivity.this, "The Yellow markers display fast food establishments located in Arbroath", Toast.LENGTH_SHORT).show();
    }
});


        LatLng CurrentPos = new LatLng(LAT,LONG); // sets current position to var by storing the received intents
        LatLng ArbroathPos = new LatLng(56.559107, -2.591543); // sets arbroath position to var by storing arbroath cords
        Grill21Pos = new LatLng(56.562519438532696,-2.5840066800569486);
        BrewhousePos = new LatLng(56.55671695881272, -2.579914939459808);
        BoatyardPos = new LatLng(56.55632319144757, -2.585630885429957);
        PortcullisPos = new LatLng(56.567797015922686, -2.578894234818483);
        McdsPos = new LatLng(56.55029967385232, -2.6108147263182127);
        KFCPos = new LatLng(56.55091470247877, -2.6114906429792923);
        // sets positions to vars by storing cords
        this.map.moveCamera(CameraUpdateFactory.zoomTo(12)); // moves camera to zoom in to 12
        this.map.moveCamera(CameraUpdateFactory.newLatLng(ArbroathPos)); // moves camera to Arbroath location

        Grill21 = map.addMarker(new MarkerOptions() // adds specific maker to map
                .position(Grill21Pos) // gets the position
                .title("Grill21") // sets the title
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)) // sets the colour
        );


        BrewHouse = map.addMarker(new MarkerOptions()// adds specific maker to map
                .position(BrewhousePos)
                .title("The Old Brewhouse")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
        );

        Boatyard = map.addMarker(new MarkerOptions()// adds specific maker to map
                .position(BoatyardPos)
                .title("The Old Boatyard")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
        );

        Portcullis = map.addMarker(new MarkerOptions()// adds specific maker to map
                .position(PortcullisPos)
                .title("The Portcullis")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
        );

        Mcds = map.addMarker(new MarkerOptions()// adds specific maker to map
                .position(McdsPos)
                .title("McDonald's")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW))
        );
        KFC = map.addMarker(new MarkerOptions()// adds specific maker to map
                .position(KFCPos)
                .title("KFC")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW))
        );
         Current = map.addMarker(new MarkerOptions()// adds specific maker to map
                .position(CurrentPos)
                .title("your current location")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
        );


        map.setOnMarkerClickListener(this); // creats an onlick for all markers





    }


    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
    // starts browser activty when a marker is clicked on and then loads the restaurants website
        if(marker.equals(Grill21)){
            Intent intent = new Intent(MapsActivity.this, BrowserActivity.class); //store intents
            intent.putExtra("URL", URL[0]); // adds extras from URL array
            startActivity(intent); //starts the browser activty and passes the data
        }else if(marker.equals(BrewHouse)){
            Intent intent = new Intent(MapsActivity.this, BrowserActivity.class);
            intent.putExtra("URL1", URL[1]);
            startActivity(intent);


        }else if(marker.equals(Boatyard)){
            Intent intent = new Intent(MapsActivity.this, BrowserActivity.class);
            intent.putExtra("URL2", URL[2]);
            startActivity(intent);

        }else if (marker.equals(Portcullis)){
            Intent intent = new Intent(MapsActivity.this, BrowserActivity.class);
            intent.putExtra("URL3", URL[3]);
            startActivity(intent);


        }else if(marker.equals(Mcds)){
            Intent intent = new Intent(MapsActivity.this, BrowserActivity.class);
            intent.putExtra("URL4", URL[4]);
            startActivity(intent);



        }else if(marker.equals(KFC)){
            Intent intent = new Intent(MapsActivity.this, BrowserActivity.class);
            intent.putExtra("URL5", URL[5]);
            startActivity(intent);


        }

        return false;
    }

    @Override
    public void onUserClicked(int position) {
        // when a restaurant is clicked on in the recycler view it will move the camera to that marker

            if(position == 0){ // if the position is clicked on in the recycler view

                map.animateCamera(CameraUpdateFactory.newLatLng(Grill21Pos)); // moves camera to the specific marker
            }else if(position == 1){

                map.animateCamera(CameraUpdateFactory.newLatLng(BrewhousePos));

            }else if(position == 2){

                map.animateCamera(CameraUpdateFactory.newLatLng(BoatyardPos));

            }else if(position == 3){

                map.animateCamera(CameraUpdateFactory.newLatLng(PortcullisPos));
            }else if(position == 4){

                map.animateCamera(CameraUpdateFactory.newLatLng(McdsPos));

            }else if(position == 5){

                map.animateCamera(CameraUpdateFactory.newLatLng(KFCPos));

            }





    }

private void animateFab(){

if(isOpen){ //if the fab buttons are open and clicked on the animation will take place

    fab.startAnimation(rotateForward);
    fab1.startAnimation(fabClose);
    fab2.startAnimation(fabClose);
    fab3.startAnimation(fabClose);
    fab1.setClickable(false);
    fab2.setClickable(false);
    fab3.setClickable(false);
    isOpen=false;
}else { //if the fab buttons are closed and clicked on the animation will take place

    fab.startAnimation(rotateBackward); //
    fab1.startAnimation(fabOpen);
    fab2.startAnimation(fabOpen);
    fab3.startAnimation(fabOpen);
    fab1.setClickable(true);
    fab2.setClickable(true);
    fab3.setClickable(true);
    isOpen=true;


}


}

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }
}
